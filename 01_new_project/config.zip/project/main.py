from src.app.module import func, err


if __name__ == '__main__':
    print(func())
    print(err())